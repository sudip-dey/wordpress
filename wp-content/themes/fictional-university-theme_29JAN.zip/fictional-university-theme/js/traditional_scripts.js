//import {$,jQuery} from 'jquery';
/* jQuery(function($) {
    
    alert("testing");

});*/

