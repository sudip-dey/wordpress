<?php
add_action('rest_api_init', 'university_custom_route');

function university_custom_route(){
    register_rest_route('university/v1', 'search', array(
        'methods' => 'GET',
        'callback' => 'university_search_results'
    ));
}

function university_search_results(){
    //return array('Congratulations');

    $searchResults = new WP_Query(array(
        'post_type' => array('posts', 'event', 'pages', 'program'),
        's' => 'lorem', // Passing the search value from API
        
    ));

$mainResult = array(
    'posts' => array(),
    'pages' => array(),
    'programs' => array(),
    'events' => array()
);

    /*while ($searchResults->have_posts()){
        $searchResults->the_post();
       /* if get_post_type() equals posts
            array_push(posts, array('' => ''),)
        if get_post_type() equals events
            array_push(posts, array('' => ''),)

    }*/

    return $mainResult;
}



