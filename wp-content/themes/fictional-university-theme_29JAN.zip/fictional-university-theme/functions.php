<?php

require get_theme_file_path('.\inc\search-route.php');

function university_files() {
  wp_enqueue_script('main-university-js', get_theme_file_uri('/js/scripts-bundled.js'), NULL, '1.0', true);

  //wp_enqueue_script('traidiontal_js', get_theme_file_uri('/js/traditional_scripts.js'), array('jquery'), '1.0', true);

  wp_localize_script('main-university-js', 'myScript', array(
    'customVal' => site_url(),
  ));
  wp_enqueue_style('custom-google-fonts', '//fonts.googleapis.com/css?family=Roboto+Condensed:300,300i,400,400i,700,700i|Roboto:100,300,400,400i,700,700i');
  wp_enqueue_style('font-awesome', '//maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css');
  wp_enqueue_style('university_main_styles', get_stylesheet_uri());
}

add_action('wp_enqueue_scripts', 'university_files');

function university_features() {
  add_theme_support('title-tag');
}

add_action('after_setup_theme', 'university_features');

add_action('init', 'university_event_post');
add_action('init', 'university_program_post');

function university_event_post(){
  register_post_type( 'event', array(
    'show_in_rest' => true, // enable the Post type in REST
    'supports' => array(
      'title', 'editor', 'excerpt'
    ),
    'has_archive' => TRUE,
    'rewrite' => array( 'slug' => 'event' ),
    'public' => true,
    'label'  => 'Events',
    'menu_icon' => 'dashicons-calendar',
    'labels' => array(
      'add_new' => "Add New Events",
      'add_new_item' => "Add New Events"
    )
    )
  );
}

function university_program_post(){
  register_post_type( 'program', array(
    'supports' => array(
      'title', 'editor', 'excerpt'
    ),
    'has_archive' => TRUE,
    'rewrite' => array( 'slug' => 'program' ),
    'public' => true,
    'label'  => 'Programs',
    'menu_icon' => 'dashicons-calendar',
    'labels' => array(
      'add_new' => "Add New Programs",
      'add_new_item' => "Add New Programs"
    )
    )
  );
}


add_action ('pre_get_posts', 'university_pre_post_alter');

function university_pre_post_alter( $query ){
  if( is_post_type_archive('event') && is_main_query() ){
    $query->set( 'orderby', 'title' );
    $query->set( 'order', 'DESC' );
    // Add the alters as requirted
  }
}


add_action('rest_api_init', 'university_custom_rest');

function university_custom_rest(){
  register_rest_field('post', 'authorName', array(
      'get_callback' => function(){ //return 'Sudip Dey'; 
          return get_the_author();
        }
  ));

}